@extends('layouts.master')

@section('title', 'Fórum | ShelbyFC')


@section('content')

    @yield('content.forum')

@endsection
