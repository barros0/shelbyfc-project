<p class="copyright">
    &copy; <script>document.write(new Date().getFullYear());</script> - <span>Shelby FC</span> All Rights Reserved.
</p>
<script>
    ClassicEditor
        .create( document.querySelector( '.editor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
