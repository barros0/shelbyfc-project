<?php $__env->startSection('title', 'Contactos | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Contactos</h1>


    <table>
        <tbody>
            <tr class="header">
                <th>ID</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Assunto</th>
                <th>Mensagem</th>
                <th>Data</th>
                <th>Eliminar</th>
                <th>Ver</th>
            </tr>
            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contact->id); ?></td>
                    <td><?php echo e($contact->name); ?></td>
                    <td><?php echo e($contact->email); ?></td>
                    <td><?php echo e($contact->phone); ?></td>
                    <td><?php echo e($contact->subject); ?></td>
                    <td><?php echo e($contact->message); ?></td>
                    <td><?php echo e($contact->created_at); ?></td>
                    <td>

                        <form action="<?php echo e(route('admin.contacts.show', $contact)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.contacts.show', $contact)); ?>">   <i class="fa fa-eye"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>