

<?php $__env->startSection('content.forum'); ?>
    <div class="">
        <div class="create_forum d-flex flex-row justify-content-around">
            <img class="user_forum_img" src="<?php echo e(asset('images/users/' . Auth::user()->image)); ?>" alt="user_img">
            <div style="width:80%;" class="d-flex flex-column">
                <form action="<?php echo e(route('forum.store_post')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input placeholder="O que estás a pensar?" type="text" name="title" id="title" required>
                    <div id="open_forum" style="display:none;">
                        <textarea placeholder="Escreva algo..." name="body" id="body" required></textarea>
                        <div class="d-flex flex-row align-items-center">
                            <input multiple hidden type="file" name="images[]" id="images">
                            <label for="images" class="custom-file-upload"><i class='bx bx-plus'></i></label>
                            <div class="preview_images"></div>
                            <i id="clear" style="display:none;" class='bx bx-x'></i>
                        </div>
                        <button type="submit" id="submit">Publicar</button>
                    </div>
                </form>
            </div>
            <div style="width: 4%">
                <i id="close" style="display:none" class='bx bx-x'></i>
            </div>
        </div>

        <div class="container_forum d-flex flex-column">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="posts_forum d-flex justify-content-around align-items-center">
                    <div class="user_info_forum">
                        <img class="user_forum_img" src="<?php echo e(asset('images/users/' . $post->user->image)); ?>" alt="user">
                        <div class="content_forum">
                            <p style="font-size: 20px"><?php echo e($post->title); ?></p>
                            <?php $__currentLoopData = $posts_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($image->post_id === $post->id): ?>
                                <img class="user_forum_img" src="<?php echo e(asset('images/noticias/' . $image->image)); ?>" alt="user">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($post->user->name); ?>,
                                <span style="color: rgb(0 0 0 / 60%);"><?php echo e($post->created_at); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="">
                        (XX)
                        Replies
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
                <span class="close">&times;</span>
                <p>Some text in the Modal..</p>
            </div>

        </div>
    </div>

    <script src="<?php echo e(asset('js/forum.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/forum/index.blade.php ENDPATH**/ ?>