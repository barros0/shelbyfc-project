<?php $__env->startSection('content-perfil'); ?>

    <h2>Minhas apostas</h2>


    <?php if(Auth::user()->bets->count() > 0): ?>
    <table>
        <tbody>
        <tr class="header">
            <th>#</th>
            <th>Jogo</th>
            <th>Valor</th>
            <th>Fator</th>
            <th>Data</th>
            <th>Data do jogo</th>
            <th>Resultado</th>
        </tr>
        <?php $__currentLoopData = Auth::user()->bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bet->id); ?></td>
                <td>Shelby vs <?php echo e($bet->game->opponent->name); ?></td>
                <td><?php echo e($bet->value); ?>€</td>
                <td><?php echo e($bet->fator); ?></td>
                <td><?php echo e($bet->created_at); ?></td>
                <td><?php echo e($bet->game->datetime_game); ?></td>
                <td>
                    <?php if($bet->game->result): ?>
                        <?php echo e($bet->game->result); ?>

                    <?php else: ?>
                        A aguardar resultado
                    <?php endif; ?>
                    </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="alert-profile">
            <h4>Você ainda não fez nenhuma aposta.</h4>

            <div class="d-flex justify-content-center">
                <a href="<?php echo e(route('tobet')); ?>" class="btn-primary btn">Ver jogos e apostar</a>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/bets.blade.php ENDPATH**/ ?>