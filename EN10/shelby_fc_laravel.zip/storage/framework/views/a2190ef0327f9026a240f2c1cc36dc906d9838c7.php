


<?php $__env->startSection('title', 'Novo jogo | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.games.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Publicar resultados</h1>

    <form action="<?php echo e(route('admin.games.publish.doresults', $game)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">


            <div class="form-group col-md-6">
                <label for="">Resultado Shelby</label>
                <input class="form-control" name="resultado_shelby" type="number" required>
            </div>

            <div class="form-group col-md-6">
                <label for="apponent">Resultado de <?php echo e($game->opponent->name); ?></label>
                <input class="form-control" name="resultado_adversario" type="number" id="opponent" required>
            </div>

            <button type="submit" class="btn btn-primary">Publicar</button>
        </div>


    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/games/results.blade.php ENDPATH**/ ?>