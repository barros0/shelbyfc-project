<?php $__env->startSection('content-perfil'); ?>

<?php if(Auth::user()->tickets->count() > 0 ): ?>


    <table>
        <tbody>
        <tr class="header">
            <th>#</th>
            <th>Descrição</th>
            <th>Valor</th>
            <th>Data do jogo</th>
            <th>Data</th>
        </tr>
        <?php $__currentLoopData = Auth::user()->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ticket->id); ?></td>
                <td>Shelby FC vs <?php echo e($ticket->opponent); ?></td>
                <td><?php echo e($ticket->value); ?>€</td>
                <td><?php echo e($ticket->game->datime_game); ?></td>
                <td><?php echo e($ticket->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="alert-profile">
        <h4>Você ainda não fez comprou nenhum bilhete.</h4>

        <div class="d-flex justify-content-center">
        <a href="<?php echo e('games'); ?>" class="btn-primary btn">Ver próximo jogos</a>
        </div>
    </div>



<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/tickets.blade.php ENDPATH**/ ?>