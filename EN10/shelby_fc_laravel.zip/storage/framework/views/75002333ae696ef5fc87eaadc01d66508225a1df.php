


<?php $__env->startSection('title', 'Equipas | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Equipas</h1>
    <div class="form-menu d-flex justify-content-between">
        <div class="form-search">
            <input type="text" name="" class="form-control" placeholder="Search">
        </div>
        <a href="<?php echo e(route('admin.teams.create')); ?>" class="btn">Adicionar</a>
    </div>
    <table>
        <tbody>
            <tr class="header">
                <th>ID</th>
                <th></th>
                <th>name</th>
                <th>Actions</th>
            </tr>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($team->id); ?></td>
                    <td><img style="width: 60px" src="<?php echo e(asset('images/liga/'.$team->image)); ?>" alt=""></td>
                    <td><?php echo e($team->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.teams.edit', $team)); ?>" class="btn"><i
                                class='bx bx-edit-alt'></i></a>
                        <form action="<?php echo e(route('admin.teams.destroy', $team)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/teams/index.blade.php ENDPATH**/ ?>