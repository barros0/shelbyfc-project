<?php $__env->startSection('title', 'News | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.news.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Editar Noticia</h1>

    <form action="<?php echo e(route('admin.news.update', $news->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="title_new">Title</label>
                    <input type="text" class="form-control" name="title" id="title_new" value="<?php echo e($news->title); ?>"
                        required>
                </div>
                <div class="form-group">
                    <label for="small_description_new">Small Description</label>
                    <input type="text" class="form-control" name="small_description"
                        value="<?php echo e($news->small_description); ?>" required>
                </div>
                <textarea name="body" class="editor"><?php echo e($news->body); ?></textarea>
                <div class="form-group">
                    <label for="image">Image</label>
                    <input class="form-control" name="image" type="file" id="image">
                </div>
                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>
            <div class="col-lg-3">
                <h3>Categoria</h3>
                <div class="form-group">
                    <select name="categorie_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>