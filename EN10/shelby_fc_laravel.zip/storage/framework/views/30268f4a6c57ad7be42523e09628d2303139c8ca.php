<?php $__env->startSection('title','Minha conta | ShelbyFC'); ?>


<?php $__env->startSection('content'); ?>


    <section class="col-12 ">

        <div class=" vh-100 d-flex flex-wrap">

            <nav class="nav-conta container-user-settings ">
                <div class="nav-conta-wrap">
                    <div class="title">
                        <h3>Definições de conta</h3>
                    </div>

                    <ul class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist"
                        aria-orientation="vertical">
                        <li>
                            <a href="#" class="active"
                               class="active" id="v-pills-perfil-tab" data-bs-toggle="pill"
                               data-bs-target="#v-pills-perfil" type="button" role="tab" aria-controls="v-pills-perfil"
                               aria-selected="true"
                            >
                                <i class="fa fa-user"></i>
                                Perfil
                            </a>
                        </li>
                        <li>
                            <a href="#" id="v-subscricoes-tab" data-bs-toggle="pill"
                               data-bs-target="#v-subscricoes" type="button" role="tab"
                               aria-controls="v-subscricoes" aria-selected="false">
                                <i class="fa-sharp fa-solid fa-handshake"></i>
                                Subscrições
                            </a>
                        </li>
                        <li>
                            <a href="#" id="v-seguranca-tab" data-bs-toggle="pill"
                               data-bs-target="#v-seguranca" type="button" role="tab"
                               aria-controls="v-seguranca" aria-selected="false">
                                <i class="fa fa-lock"></i>
                                Segurança
                            </a>
                        </li>
                        <li>
                            <a href="#" id="v-transacoes-tab" data-bs-toggle="pill"
                               data-bs-target="#v-transacoes" type="button" role="tab"
                               aria-controls="v-transacoes" aria-selected="false">
                                <i class="fa fa-coins"></i>
                                Transações
                            </a>
                        </li>
                        <li>
                            <a href="#" id="v-preferencias-tab" data-bs-toggle="pill"
                               data-bs-target="#v-preferencias" type="button" role="tab"
                               aria-controls="v-preferencias" aria-selected="false">
                                <i class="fa-solid fa-arrow-right-arrow-left"></i>
                                Preferências
                            </a>
                        </li>
                    </ul>

                    <div class="logout d-flex justify-content-center align-items-center">
                        <i class="fa-sharp fa-solid fa-arrow-right-from-bracket"></i>
                        <p>Sair</p>
                    </div>
                </div>
            </nav>


            <div class="tab-content justify-content-center">
                <div class="tab-content" id="v-pills-tabContent">

                    <div class="fade show active" id="v-pills-perfil" role="tabpanel"
                         aria-labelledby="v-pills-perfil-tab">
                        <?php echo $__env->make('perfil.partials.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                    
                    <div class="fade" id="v-subscricoes" role="tabpanel" aria-labelledby="v-subscricoes-tab">
                        <?php echo $__env->make('perfil.partials.subscricoes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    
                    <div class="fade" id="v-seguranca" role="tabpanel" aria-labelledby="v-seguranca-tab">
                        <?php echo $__env->make('perfil.partials.seguranca', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    
                    <div class="fade" id="v-transacoes" role="tabpanel" aria-labelledby="v-transacoes-tab">
                        <?php echo $__env->make('perfil.partials.transacoes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    
                    <div class="fade" id="v-preferencias" role="tabpanel" aria-labelledby="v-preferencias-tab">
                        <?php echo $__env->make('perfil.partials.preferencias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/index.blade.php ENDPATH**/ ?>