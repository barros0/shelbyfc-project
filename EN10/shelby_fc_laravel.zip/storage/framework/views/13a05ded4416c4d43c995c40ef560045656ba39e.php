<?php $__env->startSection('title','News | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Utilizadores</h1>


    <table>
        <tbody>
        <tr class="header">
            <th>#</th>
            <th>Imagem</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Estado</th>
            <th>Editar</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td> <img style="max-height: 40px" src="<?php echo e(asset('images/users/'. $user->image)); ?>" alt=""></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->status); ?></td>
            <td><a href="<?php echo e(route('admin.users.edit',$user->id)); ?>">
                    <i class="fa fa-pen"></i>
                </a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>