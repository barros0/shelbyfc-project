<?php $__env->startSection('title', 'Jogo Shelby vs'. $game->opponent->name .' | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.games.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Jogo Shelby vs <?php echo e($game->opponent->name); ?></h1>


    <div class="row">
        <div class="col-sm-6">
            <span class="bold">Stock de bilhetes:</span>
            <span> <?php echo e($game->stock_tickets); ?></span>
        </div>
    </div>







    <?php echo e($game->location); ?>


    <?php echo e($game->ticket_price); ?>


    <?php echo e($game->ticket_price_partner); ?>


    <?php echo e($game->opponent->name); ?>



    <?php echo e($game->limit_buy_ticket); ?>


    <?php echo e($game->stock_tickets); ?>


    <?php echo e($game->datetime_game); ?>






    <?php if(!$game->result_home || !$game->result_opponent): ?>
    <form action="<?php echo e(route('admin.games.publish.doresults', $game)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2>Publicar resultados</h2>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="">Resultado Shelby</label>
                <input class="form-control" name="resultado_shelby" type="number" required>
            </div>

            <div class="form-group col-md-6">
                <label for="apponent">Resultado de <?php echo e($game->opponent->name); ?></label>
                <input class="form-control" name="resultado_adversario" type="number" id="opponent" required>
            </div>

            <button type="submit" class="btn btn-primary">Publicar</button>
        </div>
    </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/games/show.blade.php ENDPATH**/ ?>