<?php $__env->startSection('title','Dashboard | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Bem vindo, <?php echo e(Auth::user()->name); ?>!</h1>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/index.blade.php ENDPATH**/ ?>