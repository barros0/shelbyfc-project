<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<header>
    <div class="navbar-esq">
        <div class="logo">
            <a class="link-logo" href="<?php echo e(route('index')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
            </a>
        </div>
    </div>

    <div class="navbar-dir">

        <a href="<?php echo e(route('register')); ?>" id="conta">CRIAR CONTA</a>

    </div>
</header>

<div id="seccao-login" class="d-flex justify-content-center align-items-center fullvh">
    <section id="login" class="col-12">
        <div class="row text-center col-12 title-login">
            <h3 class="tit">Bem-Vindo de Volta!</h3>
        </div>
        <div class="login-wrapper">
            <div class="login-regular">
                <form class="form-login" method="post" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="email">EMAIL</label>
                    <input value="<?php echo e(old('email')); ?>" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" id="email" name="email" placeholder="nome@exemplo.com" required autocomplete="email" autofocus onkeyup="enableSubmit()">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label for="password">PASSWORD </label>

                    <div class="pass-container">
                        <input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> type="password" name="password" id="password" placeholder="Password" required autocomplete="current-password" class="required" onkeyup="enableSubmit()">
                        <i class="fas fa-eye" id="eye" onclick="showPass()"></i>
                        <a href="#" class="frgt">Esqueceu-se da Password?</a>
                    </div>
                    <?php if($errors->all()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($error); ?></strong>
                    </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input type="submit" id="login-btn" class="btn-login" value="INICIAR SESSÃO" disabled="disabled">
                </form>
            </div>
            <div class="vl">
                <span class="vl-innertext">OU</span>
            </div>
            <div class="login-socials">

                <a href="<?php echo e(route('social.redirect','google')); ?>" class="social">
                    <div class="logo-social"><img src="<?php echo e(asset('images/icons/google.svg')); ?>" alt="Google"></div>
                    <div class="nome-social">Continuar com o Google</div>
                </a>

                <a href="<?php echo e(route('social.redirect','facebook')); ?>" class="social">
                    <div class="logo-social"><img src="<?php echo e(asset('images/icons/apple.svg')); ?>" alt="Apple"></div>
                    <div class="nome-social">Continuar com a Apple</div>
                </a>

                <a href="<?php echo e(route('social.redirect','facebook')); ?>" class="social">
                    <div class="logo-social"><img src="<?php echo e(asset('images/icons/facebook.svg')); ?>" alt="Facebook"></div>
                    <div class="nome-social">Continuar com o Facebook</div>
                </a>
            </div>

        </div>
        <div class="row text-center col-12 title-login">
            <a href="<?php echo e(route('forget.password.get')); ?>" class="trouble">NÃO CONSEGUE INICIAR SESSÃO?</a>
            <div class="linha-ajuda"></div>
        </div>
        <div class="row footer-bg col-12 title-login"></div>

    </section>
</div>

<div class="background">
    <div class="dir"></div>
    <div class="left"></div>
</div>


<script src="<?php echo e(asset('js/login.js')); ?>"></script>
<?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/auth/login.blade.php ENDPATH**/ ?>