<?php $__env->startSection('title','News | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Transferências de saldo</h1>


    <table>
        <tbody>
        <tr class="header">
            <th>#</th>
            <th>Nome</th>
            <th>Valor</th>
            <th>Estado</th>
            <th>Ver</th>
        </tr>
        <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($withdraw->id); ?></td>
            <td><?php echo e($withdraw->user->name); ?></td>
            <td><?php echo e($withdraw->value); ?>€</td>
            <td>
                <?php if($withdraw->complete): ?>
                    <p class="btn-success">
                        Completo
                    </p>
                <?php else: ?>
                    <p class="btn-warning">
                        Pendente
                    </p>
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(route('admin.withdraw.show',$withdraw->id)); ?>">
                    <i class="fa fa-eye"></i>
                </a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/withdraw/index.blade.php ENDPATH**/ ?>