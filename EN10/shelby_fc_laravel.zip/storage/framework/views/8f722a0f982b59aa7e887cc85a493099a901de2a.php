<nav id="navbar" class="d-flex">
    <div class="navbar-logo-container d-flex justify-content-center">
        <a class="" href="<?php echo e(route('index')); ?>">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
        </a>
    </div>
    <div class="navbar-menu-container">
        <div class="navbar-info-container d-flex flex-row justify-content-around">
            <div class="d-flex justify-content-around align-items-center">
                <p class="d-flex align-items-center"><i class='bx bxs-phone'></i> 244 144 102</p>
                <div class="line"></div>
                <p class="d-flex align-items-center"><i class='bx bxs-envelope'></i> shelbyfc@gmail.com</p>
            </div>
            <div class="d-flex justify-content-around align-items-center">
                <?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('withdraw')); ?>"><?php echo e(Auth::user()->balance); ?>€</a>

                    <a href="<?php echo e(route('perfil')); ?>">Minha conta</a>

                    <?php if(Auth::user()->is_admin): ?>
                        <div class="line"></div>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">Administração</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                    <div class="line"></div>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="navbar-navigation-container d-flex">
            <div class="navbar-third-container d-flex align-items-center justify-content-center">
                <ul>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" target="_blank"
                            href="https://teste.social-bubble.pt">
                            Loja Online
                        </a>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('forum.home')); ?>">
                            Forúm
                        </a>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('noticias')); ?>">
                            Notícias
                        </a>
                    </li>
                    <li>
                        Jogos
                        <ul>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('forum.home')); ?>">
                                    Calendário
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('forum.home')); ?>">
                                    Bilheteira
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('tobet')); ?>">
                                    Apostar
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        Suporte
                        <ul>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('sobre')); ?>">
                                    Quem Somos
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('faqs')); ?>">
                                    FAQs
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('forum.home')); ?>">
                                    Termos e Condições
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('contacts')); ?>">
                                    Contactos
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('inscrever')); ?>">
                            Sócio
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/partials/nav.blade.php ENDPATH**/ ?>