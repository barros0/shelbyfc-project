


<?php $__env->startSection('title', 'News | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Noticias</h1>
    <div class="form-menu d-flex justify-content-between">
        <div class="form-search">
            <input type="text" name="" class="form-control" placeholder="Search">
        </div>
        <a href="<?php echo e(route('admin.news.create')); ?>" class="btn">Adicionar</a>
    </div>
    <table>
        <tbody>
            <tr class="header">
                <th>ID</th>
                <th>Title</th>
                <th>IMG</th>
                <th>Category</th>
                <th>Views</th>
                <th>Actions</th>
            </tr>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($new->id); ?></td>
                    <td><?php echo e($new->title); ?></td>
                    <td><?php echo e($new->image); ?></td>
                    <td><?php echo e($new->categorie->name); ?></td>
                    <td><?php echo e($new->views); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.news.edit', $new)); ?>" class="btn"><i class='bx bx-edit-alt'></i></a>
                        <form action="<?php echo e(route('admin.news.destroy', $new)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/news/index.blade.php ENDPATH**/ ?>