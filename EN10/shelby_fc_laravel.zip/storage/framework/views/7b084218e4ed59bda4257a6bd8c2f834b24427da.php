

<?php $__env->startSection('content-perfil'); ?>

    <?php if(empty($subscriptions)): ?>

        <div class="alert-profile">
            <h4>Você ainda não fez nenhuma subscrição</h4>
        </div>

    <?php else: ?>

        <table>
            <tbody>
            <tr class="header">
                <th>#</th>
                <th>Estado</th>
                <th>Valor</th>
                <th>Subscreveu a:</th>
                <th>Expira/ou:</th>
            </tr>
            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subscription->id); ?></td>
                    <td><?php echo e($subscription->state); ?></td>
                    <td><?php echo e($subscription->value); ?>€</td>
                    <td>
<?php if($subscription->state == 'Pendente'): ?>
                            <a href="<?php echo e(route('paypal.pay.subscription', $subscription)); ?>" class="btn btn-primary"></a>
                        <?php else: ?>
                            <?php echo e($subscription->created_at); ?>

    <?php endif; ?>


                    </td>
                    <td><?php echo e($subscription->expires_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/subscricoes.blade.php ENDPATH**/ ?>