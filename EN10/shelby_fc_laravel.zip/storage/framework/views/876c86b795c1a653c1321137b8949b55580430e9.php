

<?php $__env->startSection('title', 'ShelbyFC'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container_main_new">
        <div class="mask-gradient">
            <img id="image" src="<?php echo e(asset('images/noticias/')); ?>" alt="image">
        </div>
        <div class="container_new">
            <div class="news_details">
                <h1 id="news_title"></h1>
                <div class="news_btn_date">
                    <button>Ler Mais</button>
                    <p id="news_date"></p>
                </div>
            </div>
            <div class="news_options">
                <?php $__currentLoopData = $noticias->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="option" id="option<?php echo e($id_js = $id_js + 1); ?>">
                        <p id="image<?php echo e($id_image_js = $id_image_js + 1); ?>" style="display:none;"><?php echo e($noticia->image); ?></p>
                        <p id="date<?php echo e($id_date_js = $id_date_js + 1); ?>"><?php echo e($noticia->created_at->format('Y-m-d')); ?></p>
                        <h3 id="text<?php echo e($id_text_js = $id_text_js + 1); ?>"><?php echo e($noticia->title); ?></h3>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <a class="see_more" href="">Ver mais &#x2192;</a>
    <div class="container_last_matches">
        <div class="match">
            <div class="match_home d-flex flex-column justify-content-between align-items-center">
                <img src="<?php echo e(asset('images/liga/estrela_da_amadora.png')); ?>" alt="logo-estrela_da_amadora">
                <p class="team_name">Estrela da Amadora</p>
            </div>
            <div class="match_info">
                <p>Amigável</p>
                <div class="score">
                    <p class="score_home">2</p>
                    <p class="score_away">2</p>
                </div>
                <p>15 Jun 2022</p>
            </div>
            <div class="match_away d-flex flex-column justify-content-between align-items-center">
                <img src="<?php echo e(asset('images/liga/shelby_fc.png')); ?>" alt="logo-shelby">
                <p class="team_name">Shelby FC</p>
            </div>
        </div>
        <div class="separador"></div>
        <div class="match">
            <div class="match_home d-flex flex-column justify-content-between align-items-center">
                <img src="<?php echo e(asset('images/liga/UD_Oliveirense.png')); ?>" alt="logo-UD_Oliveirense">
                <p class="team_name">Oliveirense</p>
            </div>
            <div class="match_info">
                <p>Amigável</p>
                <div class="score">
                    <p class="score_home">0</p>
                    <p class="score_away">3</p>
                </div>
                <p>15 Jun 2022</p>
            </div>
            <div class="match_away d-flex flex-column justify-content-between align-items-center">
                <img src="<?php echo e(asset('images/liga/shelby_fc.png')); ?>" alt="logo-shelby">
                <p class="team_name">Shelby FC</p>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/index.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/index.blade.php ENDPATH**/ ?>