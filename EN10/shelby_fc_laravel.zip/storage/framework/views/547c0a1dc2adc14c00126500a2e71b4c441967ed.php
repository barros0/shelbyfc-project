

<?php $__env->startSection('title', 'FaQS | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>
    <div class="conteudo-faqs">
        <div class="imagem-inicio">

            <div class="parte-baixo-banner">
                <div class="texto-banner">Apoio ao Cliente</div>
                <p>Encontre aqui a resposta a todas as suas questões</p>
            </div>
        </div>


        <div class="section-faqs container">
            <h1>Informações de sócio</h1>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($faq->categoria == 'informacoes'): ?>
                    <button class="accordion"><?php echo $faq->pergunta; ?></button>
                <?php endif; ?>
                <div class="panel">
                    <p><?php echo $faq->resposta; ?></p>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            <h1>Criar conta</h1>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($faq->categoria == 'criar_conta'): ?>
                    <button class="accordion"><?php echo $faq->pergunta; ?></button>
                <?php endif; ?>
                <div class="panel">
                    <p><?php echo $faq->resposta; ?></p>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            <h1>Jogos e Apostas</h1>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($faq->categoria == 'jogos_apostas'): ?>
                    <button class="accordion"><?php echo $faq->pergunta; ?></button>
                <?php endif; ?>
                <div class="panel">
                    <p><?php echo $faq->resposta; ?></p>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            <h1>Depósitos e Levantamentos</h1>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($faq->categoria == 'depositos_levantamentos'): ?>
                    <button class="accordion"><?php echo $faq->pergunta; ?></button>
                <?php endif; ?>
                <div class="panel">
                    <p><?php echo $faq->resposta; ?></p>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>

        <div class="fale-conosco">
            <div class="imagem-fale-conosco">
                <div class="lado-esquerdo">
                    <div class="titulo-fale-conosco">
                        <p> Fale Connosco</p>
                    </div>
                    <div class="texto-fale-conosco">
                        <p>Para entrar em contacto connosco clique, por favor,</p>
                        <p> no botão para enviar a sua mensagem.</p>
                    </div>
                    <div class="btn-section">
                        <button type="button" class="btn-send">Enviar Mensagem</button>
                    </div>
                </div>
                <div class="lado-direito"></div>

            </div>

        </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/faqs.blade.php ENDPATH**/ ?>