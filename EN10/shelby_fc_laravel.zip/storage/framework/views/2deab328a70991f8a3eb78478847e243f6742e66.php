<?php $__env->startSection('perfil.active','perfil'); ?>

<?php $__env->startSection('content-perfil'); ?>
    <div class="d-flex justify-content-center-no justify-itens-center">

        <form class="form-profile" action="<?php echo e(route('dowithdraw')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                  <h5>Saldo atual: <?php echo e(Auth::user()->balance); ?>€</h5>
                <p class="text-danger">Minimo de levantamento: 10€</p>
                <p>Insira o IBAN da conta bancária para onde pretende que enviemos o seu saldo:</p>

                <div class="col-12 form-group">
                    <label class="form-label" for="iban">IBAN</label>
                    <input class="" type="text" name="iban" id="iban" value="">
                </div>

                <div class="col-lg-6 text-center">
                    <div>
                        <button type="submit" class="btn bt-fix">
                            Levantar
                        </button>
                    </div>
                </div>
            </div>
        </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/withdraw.blade.php ENDPATH**/ ?>