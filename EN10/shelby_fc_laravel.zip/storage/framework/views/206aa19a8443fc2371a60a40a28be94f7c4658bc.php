

<?php $__env->startSection('content-perfil'); ?>

<?php if(empty(Auth::user()->transactions)): ?>

    <div class="alert-profile">
    <h4>Você ainda não fez nenhuma transação</h4>
    </div>

<?php else: ?>


    <table>
        <tbody>
        <tr class="header">
            <th>#</th>
            <th>Descrição</th>
            <th>Valor</th>
            <th>Data</th>
        </tr>
        <?php $__currentLoopData = Auth::user()->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($transacao->id); ?></td>
            <td><?php echo e($transacao->description); ?></td>
            <td><?php echo e($transacao->value); ?>€</td>
            <td><?php echo e($transacao->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/transacoes.blade.php ENDPATH**/ ?>