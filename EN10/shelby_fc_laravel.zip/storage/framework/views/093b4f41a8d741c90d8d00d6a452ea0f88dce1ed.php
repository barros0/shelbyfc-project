<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Editar Equipa</h1>

    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="nome">Nome</label>
                <input type="text" class="form-control" name="nome" id="nome" value="<?php echo e($user->name); ?>"
                       required>
            </div>

            <div class="form-group col-md-6">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" id="email" value="<?php echo e($user->email); ?>"
                       required>
            </div>


            <div class="form-group col-md-6">
                <label for="name">Email</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($user->email); ?>"
                       required>
            </div>


            <button type="submit" class="btn btn-primary">Inserir</button>
        </div>
    </form>

    <div class="row">

        <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Eliminar utilizador permanentemente</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>