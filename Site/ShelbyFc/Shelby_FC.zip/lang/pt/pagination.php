<?php
declare(strict_types=1);

return [
    'previous' => '&laquo; Anterior',
    'next' => 'Seguinte &raquo;',
    'goto_page' => 'Página #:page',
];
