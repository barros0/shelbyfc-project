@extends('layouts.admin.master')


@section('title', 'Termos & Condições | Shelby FC')

@section('content')


    <h1>Termos & Condições</h1>
    <div class="form-menu d-flex justify-content-between">

        <a href="{{ route('admin.terms.create') }}" class="btn">Adicionar</a>
    </div>
    <div class="table-responsive">
        <table class="datatable">
            <thead>
            <tr class="header">
                <th>ID</th>
                <th>Titulo</th>
                <th>Categoria</th>
                <th>Eliminar</th>

            </tr>
            </thead>
            <tbody>
            @foreach ($terms as $term)
                <tr>
                    <td>{!! $term->id !!}</td>
                    <td>{!! $term->titulo !!}</td>
                    <td>{!! $term->categoria !!}</td>
                    <td>
                    <a href="{{ route('admin.terms.edit', $term) }}" class="btn"><i class='bx bx-edit-alt'></i></a>
                        <form action="{{ route('admin.terms.show', $term) }}" method="post">
                            @method('delete')
                            @csrf
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>
                    </td>

                </tr>
            @endforeach
            </tbody>
        </table>

    </div>


@endsection
