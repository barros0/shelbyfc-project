<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use Laravel\Socialite\Facades\Socialite;
use App\Http\Controllers\Auth\SocialLoginController;
use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\GamesController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminForumController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PostsController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\PayPalController;
use App\Http\Controllers\InscreverController;
use App\Http\Controllers\TeamsController;
use App\Http\Controllers\FaqsController;
use App\Http\Controllers\ContactsController;
use App\Http\Controllers\TermsController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\BetsController;
use App\Http\Controllers\ForumRepliesController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\SobreController;
use \App\Http\Controllers\WithdrawController;
use App\Http\Controllers\TicketsController;
use App\Http\Controllers\Auth\VerificationController;
use App\Http\Controllers\ForumCommentsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/**--------------------tests--------------------**/
/**-----------------tests--------------------**/

Auth::routes();
Auth::routes(['verify' => true]);

Route::get('/verify-email/{token}', [VerificationController::class, 'verify_email'])->name('email.verify');

Route::get('/', [PageController::class, 'index'])->name('index');
Route::get('/home', [PageController::class, 'index'])->name('home');
Route::get('styles', [PageController::class, 'styles'])->name('styles');


/** AUTH PROVIDERS & CALLBACK**/
Route::get('auth/{provider}/callback', [SocialLoginController::class, 'providerCallback']);
Route::get('auth/{provider}', [SocialLoginController::class, 'redirectToProvider'])->name('social.redirect');

Route::get('forget-password', [ForgotPasswordController::class, 'showForgetPasswordForm'])->name('forget.password.get');
Route::post('forget-password', [ForgotPasswordController::class, 'submitForgetPasswordForm'])->name('forget.password.post');
Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');
Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('reset.password.post');

Route::group(['middleware' => ['auth']], function () {
    Route::post('/verify-email-resend', [VerificationController::class, 'resend_verify_email'])->name('email.verify.resend');

    Route::get('perfil', [PageController::class, 'minha_conta'])->name('perfil');
});

Route::group(['middleware' => ['auth', 'verified', 'AuthorizedUser']], function () {

    Route::get('carrinho', [CartController::class, 'cart'])->name('cart');

    Route::get('/inscrever', [PageController::class, 'inscrever'])->name('inscrever');
    Route::post('/inscrever', [PageController::class, 'inscrever_post'])->name('inscrever.post');

    Route::get('/apostar', [PageController::class, 'tobet'])->name('tobet');
    Route::post('/apostar', [BetsController::class, 'dobet'])->name('tobet.post');

    Route::get('/comprar-bilhete', [PageController::class, 'buy_ticket'])->name('tickets');
    Route::post('/comprar-bilhete', [UserController::class, 'buy_ticket'])->name('tickets.buy');

    Route::get('/imprimir-bilhete/{ticket}', [TicketsController::class, 'print'])->name('print.ticket');

    Route::group(['prefix' => 'perfil'], function () {
        Route::get('/remove-photo', [UserController::class, 'remove_photo'])->name('user.remove.photo');
        Route::get('/subscricoes', [PageController::class, 'subscricoes'])->name('subscricoes');
        Route::get('/seguranca', [PageController::class, 'seguranca'])->name('seguranca');
        Route::get('/bilhetes', [PageController::class, 'tickets'])->name('my.tickets');
        Route::get('/apostas', [PageController::class, 'bets'])->name('bets');

        Route::get('/retirar-saldo', [PageController::class, 'withdraw'])->name('withdraw');
        Route::post('/retirar-saldo', [UserController::class, 'dowithdraw'])->name('dowithdraw');

        Route::post('/atualizar', [UserController::class, 'update_account'])->name('user.update');
        Route::post('/atualizar-password', [UserController::class, 'update_password'])->name('user.update.password');
    });
});

Route::get('/noticias', [PageController::class, 'noticias'])->name('noticias');
Route::get('/noticias/categoria/{category}', [PageController::class, 'news_categories'])->name('news.categorie')->withTrashed();
Route::get('/noticia/{id}', [PageController::class, 'NoticiaModal'])->name('NoticiaModal');
Route::get('/faqs', [PageController::class, 'faqs'])->name('faqs');
Route::get('/terms', [PageController::class, 'terms'])->name('terms');


Route::get('/contacts', [PageController::class, 'contacts'])->name('contacts');
Route::post('/contacts', [ContactsController::class, 'create'])->name('contacts.create');


Route::get('/jogos', [PageController::class, 'jogos'])->name('jogos');
Route::get('/resultados', [PageController::class, 'resultados'])->name('resultados');
Route::get('/sobre', [PageController::class, 'sobre'])->name('sobre');


Route::group(['prefix' => 'forum', 'as' => 'forum.', 'middleware' => ['auth', 'verified', 'AuthorizedUser', 'subscriber']], function () {
    Route::get('/', [ForumController::class, 'index'])->name('home');
    Route::get('/{post}', [ForumController::class, 'post'])->name('post');
    Route::post('/store_post', [ForumController::class, 'store_post'])->name('store_post');

    Route::post('/comentar/{post}', [ForumController::class, 'docomment'])->name('do.comment');
    Route::post('/reply/{post}', [ForumController::class, 'reply'])->name('reply');
});


Route::group(['prefix' => 'admin/', 'as' => 'admin.', 'middleware' => ['admin', 'AuthorizedUser']], function () {
    Route::get('/dashboard', [AdminController::class, 'index'])->name('dashboard');
    Route::resource('/categories', CategoriesController::class);
    Route::resource('/games', GamesController::class);
    Route::get('/publicar-resultados/{game}', [GamesController::class, 'post_results'])->name('games.publish.results');
    Route::post('/publicar-resultados/{game}', [GamesController::class, 'dopost_results'])->name('games.publish.doresults');

    Route::resource('/subscriptions', SubscriptionController::class);
    Route::resource('/tickets', TicketsController::class);
    Route::resource('/comments', ForumCommentsController::class);
    Route::resource('/replies', ForumRepliesController::class);
    Route::resource('/forum_posts', AdminForumController::class);
    Route::resource('/users', UserController::class);
    Route::resource('/news', NewsController::class);
    Route::resource('/inscrever', InscreverController::class);
    Route::resource('/teams', TeamsController::class);
    Route::resource('/faqs', FaqsController::class);
    Route::resource('/terms', TermsController::class);
    Route::resource('/contacts', ContactsController::class);
    Route::resource('/withdraw', WithdrawController::class);
});


Route::get('create-transaction', [PayPalController::class, 'createTransaction'])->name('createTransaction');
Route::get('process-transaction', [PayPalController::class, 'processTransaction'])->name('processTransaction');

Route::group(['prefix' => 'paypal/', 'as' => 'paypal.'], function () {
    Route::get('success-transaction', [PayPalController::class, 'success_transaction_bet'])->name('success.transaction.bet');
    Route::get('cancel-transaction', [PayPalController::class, 'cancelTransaction'])->name('cancel.transaction');

    Route::get('success-transaction-ticket/{gameid}/{quantidade}/{price}', [PayPalController::class, 'success_transaction_ticket'])->name('success.transaction.ticket');
    Route::get('cancel-transaction-ticket', [PayPalController::class, 'cancelTransactionTicket'])->name('cancel.transaction.ticket');

    Route::get('pay-subscription/{subscription}', [PayPalController::class, 'pay_subscription'])->name('pay.subscription');


    Route::get('success-transaction-subscription/{subscription}', [PayPalController::class, 'success_transaction_subscription'])->name('success.transaction.subscription');
    Route::get('cancel-transaction-subscription', [PayPalController::class, 'cancelTransactionSubscription'])->name('cancel.transaction.subscription');
});


