


<?php $__env->startSection('title', 'Dashboard | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Bem vindo, <?php echo e(Auth::user()->name); ?>!</h1>

    <div class="container_boxes">
        <div class="box">
            <i class='bx bx-user'></i>
            <p><?php echo e($users); ?> Users</p>
        </div>
        <div class="box">
            <i class='bx bx-news'></i>
            <p><?php echo e($news); ?> Noticias</p>
        </div>
        <div class="box">
            <i class='bx bx-crown'></i>
            <p><?php echo e($subscription); ?> Socios</p>
        </div>
        <div class="box">
            <i class='bx bx-phone'></i>
            <p><?php echo e($contact); ?> Contactos</p>
        </div>
    </div>

    <div class="container_recent">
        <div class="recent_box">
            <h3>Proximos 2 Jogos</h3>
            <div class="content_post">
                <?php $__currentLoopData = $nextgames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>SHELBY FC vs. <?php echo e($game->opponent->name); ?></p>
                    <p>Bilhetes Restantes - <?php echo e($game->stock_tickets); ?></p>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="recent_box">
            <h3>Ultimos 2 Jogos</h3>
            <div class="content_post">
                <?php $__currentLoopData = $lastgames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>SHELBY FC vs. <?php echo e($game->opponent->name); ?></p>
                        <p><?php echo e($game->result_home); ?> : <?php echo e($game->opponent->name); ?></p>
                        <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

    <div class="forum_recent_box">
        <h3>Forum Post Mais Recente</h3>
        <div class="content_post">
                <p><?php echo e($forum_post->title); ?> - <?php echo e($forum_post->created_at); ?></p>
                <p><?php echo e($forum_post->body); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/index.blade.php ENDPATH**/ ?>