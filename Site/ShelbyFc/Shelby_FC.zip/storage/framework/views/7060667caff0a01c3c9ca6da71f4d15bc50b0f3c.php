<?php $__env->startSection('title', 'Jogo Shelby vs '. $game->opponent->name .' | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.games.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Jogo Shelby vs <?php echo e($game->opponent->name); ?></h1>

    <div class="container my-4">

        <div class="row">

        <div class="calendar">

            <div class="match-day">
                <div class="match-details">
                    <span class="match-date"><?php echo e($data = date('d M y',strtotime($game->datetime_game))); ?></span>
                    <span class="match-hours"><?php echo e($hora = date('H:i',strtotime($game->datetime_game))); ?></span>
                    <span class="match-location"><?php echo e($game->location); ?></span>
                </div>
                <div class="teams">
                    <div class="match-home-team">
                        <img src="<?php echo e(asset('images/liga/shelby_fc.png')); ?>" alt="Shelby FC" class="match-team">
                        <span class="match-type">Shelby F.C</span>
                    </div>
                    <?php if($game->result_home !== null): ?>
                    <div class="match-result-container">
                        <div class="result-bg"><span class="match-result"><?php echo e($game->result_home); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <div class="match-vs-half"><span class="match-type">Amigável</span><h3 class="match-day-vs">VS</h3></div>
                    <?php if($game->result_opponent !== null): ?>
                    <div class="match-result-container">
                        <div class="result-bg"><span class="match-result"><?php echo e($game->result_opponent); ?></span></div>
                    </div>
                    <?php endif; ?>
                    <div class="match-away-team">
                        <img src="<?php echo e(asset('images/liga/'.$game->opponent->image)); ?>" alt="<?php echo e($game->opponent->name); ?>"  class="match-team">
                        <span class="match-type"><?php echo e($game->opponent->name); ?></span>
                    </div>
                </div>
            </div>

        </div>

        </div>

        </div>

    <?php if($game->result_home !== null || $game->result_opponent !== null): ?>
    <?php else: ?>
    <form action="<?php echo e(route('admin.games.publish.doresults', $game)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2>Publicar Resultado</h2>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="">Golos Shelby F.C</label>
                <input class="form-control" name="resultado_shelby" type="number" required>
            </div>

            <div class="form-group col-md-6">
                <label for="apponent">Golos <?php echo e($game->opponent->name); ?></label>
                <input class="form-control" name="resultado_adversario" type="number" id="opponent" required>
            </div>

            <button type="submit" class="btn btn-primary">Publicar Resultado</button>
        </div>
    </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/games/show.blade.php ENDPATH**/ ?>