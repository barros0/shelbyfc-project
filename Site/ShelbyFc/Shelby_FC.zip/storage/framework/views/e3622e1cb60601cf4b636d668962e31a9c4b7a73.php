<?php $__env->startSection('title', 'FaQs | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.faqs.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Criar FaQ</h1>

    <form action="<?php echo e(route('admin.faqs.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="pergunta_faq">Pergunta</label>
                    <input type="text" class="form-control" name="pergunta" id="pergunta_faq" placeholder="Pergunta"
                        required value="<?php echo e(old('pergunta')); ?>">
                </div>
                <div class="form-group">
                    <label for="resposta_faq">Resposta</label>
                    <input type="text" class="form-control" name="resposta" placeholder="Resposta" required value="<?php echo e(old('resposta')); ?>">
                </div>

                <div class="form-group">
                    <label for="categoria_faq">Categoria</label>
                    <select name="categoria">
                            <option value="informacoes">Informações</option>
                            <option value="jogos_apostas">Jogos e Apostas</option>
                            <option value="depositos_levantamentos">Depósitos e Levantamentos</option>
                            <option value="criar_conta">Criar Conta</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>

                </div>
            </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/faqs/create.blade.php ENDPATH**/ ?>