<?php $__env->startSection('title','Subscrições | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Subscrições</h1>


    <div class="table-responsive">
        <table class="datatable">
            <thead>
            <tr class="header">
                <th>User ID</th>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Estado Subscrição</th>
                <th>Início Subscrição</th>
                <th>Fim Subscrição</th>
                <th>Ações</th>
                <th>Subscrições</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subscription->id); ?></td>
                    <td><img style="max-height: 40px" src="<?php echo e(asset('images/users/'. $subscription->DadosUser->image)); ?>" alt=""></td>
                    <td><?php echo e($subscription->name); ?></td>
                    <td><?php echo e($subscription->email); ?></td>
                    <td><?php echo e($subscription->state); ?></td>
                    <td><?php echo e($subscription->created_at); ?></td>
                    <td><?php echo e($subscription->expires_at); ?></td>
                    <td>
                        <?php if($subscription->state != 'Ativa'): ?>
                            <a href="<?php echo e(route('admin.subscriptions.show', $subscription)); ?>" class="btn">Aprovar</a>
                        <?php endif; ?>
                    </td>
                    <td>
                            <a href="<?php echo e(route('admin.subscriptions.show', $subscription)); ?>" class="btn">Visualizar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/subscriptions/index.blade.php ENDPATH**/ ?>