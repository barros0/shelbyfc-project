<?php $__env->startSection('title', 'Inscrever | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Novo Pacote</h1>
    <a style="font-size:25px;" href="<?php echo e(route('admin.inscrever.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <form action="<?php echo e(route('admin.inscrever.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="name">Nome</label>
                    <input type="text" class="form-control" name="nome" id="name" placeholder="Nome" required>
                </div>
                <div class="form-group">
                    <label for="title_new">Idade minima</label>
                    <input type="text" class="form-control" name="idade_minima" id="idade_new"
                           required>
                </div>

                <div class="form-group">
                    <label for="title_new">Idade máxima</label>
                    <input type="text" class="form-control" name="idade_maxima" id="idade_new"
                           required>
                </div>
                <div class="form-group">
                    <label for="name">Preço</label>
                    <input type="num" class="form-control" name="preco" id="preco" placeholder="Enter Price" required>
                </div>
                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/inscrever/create.blade.php ENDPATH**/ ?>