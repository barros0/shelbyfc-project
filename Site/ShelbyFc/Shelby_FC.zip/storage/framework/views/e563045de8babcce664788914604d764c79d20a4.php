<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Resultados - Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <div class="background-foto-calendario">
        <h1 class="tit-principal">Resultados</h1>
    </div>

    <div class="container my-4">

        <div class="row">

            <div class="calendar">
  <?php if($proximos_jogos->count() == 0): ?>
      <div class="d-flex jusntify-content-center">
          <h2>Não temos jogos para os próximos tempos :(</h2>
      </div>
      <?php endif; ?>
        <?php $__currentLoopData = $proximos_jogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proximo_jogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="match-day">
            <div class="match-details">
                <span class="match-date"><?php echo e($data = date('d M y',strtotime($proximo_jogo->datetime_game))); ?></span>
                <span class="match-hours"><?php echo e($hora = date('H:i',strtotime($proximo_jogo->datetime_game))); ?></span>
                <span class="match-location"><?php echo e($proximo_jogo->location); ?></span>
            </div>
            <div class="teams">
                <div class="match-home-team">
                    <img src="<?php echo e(asset('images/liga/shelby_fc.png')); ?>" alt="Shelby FC" class="match-team">
                    <span class="match-type">Shelby F.C</span>
                </div>
                <div class="match-result-container">
                    <div class="result-bg"><span class="match-result"><?php echo e($proximo_jogo->result_home); ?></span></div>
                </div>
                <div class="match-vs-half"><span class="match-type">Amigável</span><h3 class="match-day-vs">VS</h3></div>
                <div class="match-result-container">
                    <div class="result-bg"><span class="match-result"><?php echo e($proximo_jogo->result_opponent); ?></span></div>
                </div>

                <div class="match-away-team">
                    <img src="<?php echo e(asset('images/liga/'.$proximo_jogo->opponent->image)); ?>" alt="<?php echo e($proximo_jogo->opponent->name); ?>"  class="match-team">
                    <span class="match-type"><?php echo e($proximo_jogo->opponent->name); ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/results.blade.php ENDPATH**/ ?>