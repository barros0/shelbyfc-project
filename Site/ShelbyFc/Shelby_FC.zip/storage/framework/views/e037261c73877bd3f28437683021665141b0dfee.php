<?php $__env->startSection('perfil.active','perfil'); ?>

<?php $__env->startSection('content-perfil'); ?>
    <div class="d-flex justify-content-center-no justify-itens-center">

        <div class="photo-edit-wrap">
            <div class="photo">
                <img src="<?php echo e(asset('images/users/'. Auth::user()->image)); ?>" alt="Image profile">
            </div>

            <form action="">
                <label for="photo_profile">
                    <div class="span edit">
                        <i class="fa fa-pen"></i>
                    </div>

                </label>
            </form>
        </div>

        <div class="info">
            <h3 id="name"><?php echo e(Auth::user()->name); ?></h3>
            <?php if(Auth::user()->subscribed): ?>
                <h6>Sócio - Subscrição ativa</h6>
            <?php else: ?>
                <h6>Sem subscrição ativa</h6>
            <?php endif; ?>

            <a class="btn-remove" href="<?php echo e(route('user.remove.photo')); ?>">Remover</a>
        </div>
    </div>

    <form class="form-profile" action="<?php echo e(route('user.update')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input hidden onchange="this.form.submit()" type="file" id="photo_profile" name="foto_perfil">
        <div class="row">
            <div class="col-lg-6 form-group">
                <label class="form-label" for="nome">Nome</label>
                <input class="" type="text" name="nome" id="nome" value="<?php echo e(Auth::user()->name); ?>">
            </div>
            <div class="col-lg-6 form-group">
                <label class="form-label" for="email">Email</label>
                <input class="" type="email" name="email" id="email" disabled value="<?php echo e(Auth::user()->email); ?>">
            </div>
            <div class="col-lg-6 form-group">
                <label class="form-label" for="telefone">Nº telefone</label>
                <input class="" type="text" name="telefone" id="telefone" value="<?php echo e(Auth::user()->phone); ?>">
            </div>

            <div class="col-lg-6 form-group">
                <label class="form-label" for="cidade">Cidade</label>
                <input class="" type="text" name="cidade" id="cidade" value="<?php echo e(Auth::user()->city); ?>">
            </div>

            <div class="col-lg-6 form-group">
                <label class="form-label" for="morada">Morada</label>
                <input class="" type="text" name="morada" id="morada" value="<?php echo e(Auth::user()->address); ?>">
            </div>

            <div class="col-lg-6 form-group">
                <label class="form-label" for="pais">Pais</label>
                <select class="" name="pais" id="pais">
                    <option value="">Selecione o seu pais</option>
                    <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if($country->id == Auth::user()->country_id): ?>
                            selected
                            <?php endif; ?>
                            value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="col-lg-6 form-group">
                <label class="form-label" for="codigo_postal">Código postal</label>
                <input class="" type="text" name="codigo_postal" id="codigo_postal"
                       value="<?php echo e(Auth::user()->postal_code); ?>">
            </div>

            <div class="col-lg-6 form-group">
                <label class="form-label" for="nif">NIF</label>
                <input class="" type="text" name="nif" id="nif" value="<?php echo e(Auth::user()->nif); ?>">
            </div>

            <div class="col-lg-6 form-group">
                <label class="form-label" for="morada">Data de Nascimento</label>
                <input class="" type="date" name="nascimento" id="nascimento" value="<?php echo e(Auth::user()->birthdate); ?>">
            </div>

            <div class="col-lg-6 text-center">
                <div>
                    <button type="submit" class="btn bt-fix">
                        Guardar
                    </button>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/perfil.blade.php ENDPATH**/ ?>