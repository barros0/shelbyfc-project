


<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Categories</h1>
    <div class="form-menu d-flex justify-content-between">
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn">Adicionar</a>
    </div>
    <div class="table-responsive">
    <table class="datatable">
       <thead>
            <tr class="header">
                <th>ID</th>
                <th>name</th>
                <th>Actions</th>
            </tr></thead> <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn"><i
                                class='bx bx-edit-alt'></i></a>
                        <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>