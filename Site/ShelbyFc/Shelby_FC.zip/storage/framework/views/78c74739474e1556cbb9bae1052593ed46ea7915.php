<?php $__env->startSection('title','Termos & Condições | ShelbyFC'); ?>

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <div class="conteudo-terms">
        <div class="imagem-inicio">

            <div class="parte-baixo-banner">
                <div class="texto-banner">Termos & Condições</div>
                <p>Aqui pode encontrar os nossos termos e condições</p>
            </div>
        </div>


        <div class="term-section">
            <div class="term-box">
                <div class="box-title">
                    <h2>Termos & Condições</h2>
                </div>
                <div class="box-content">
                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6><?php echo $term->titulo; ?></h6>
                        <p><?php echo $term->texto; ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/terms.blade.php ENDPATH**/ ?>