<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Alterar conta de <?php echo e($user->name); ?></h1>

    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="nome">Nome</label>
                <input type="text" class="form-control" name="nome" id="nome" value="<?php echo e($user->name); ?>"
                       required>
            </div>

            <div class="form-group col-md-6">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" id="email" value="<?php echo e($user->email); ?>"
                       required>
            </div>


            <div class="form-group col-md-6">
                <label for="name">Nova password</label>
                <input type="text" class="form-control" name="name" id="name"
                       required>
            </div>

            <div class="col-lg-3">
                <h3>Estado</h3>
                <div class="form-group">
                    <select name="estado">
                        <option <?php if($user->status == 'Pendente'): ?> selected <?php endif; ?> value="1">Pendente</option>
                        <option <?php if($user->status == 'Ativo'): ?> selected <?php endif; ?> value="2">Ativo</option>
                        <option <?php if($user->status == 'Suspenso'): ?> selected <?php endif; ?> value="3">Suspenso</option>
                        <option <?php if($user->status == 'Banido'): ?> selected <?php endif; ?> value="4">Banido</option>
                    </select>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-6">
                    <button type="submit" class="btn btn-primary">Inserir</button>
                </div>
            </div>
        </div>
    </form>

    <div class="row">
        <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
         <div class="col-sm-offset-2 m10" >
             <button type="submit" class="btn btn-primary">Eliminar utilizador permanentemente</button>
         </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>