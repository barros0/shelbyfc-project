<?php $__env->startSection('title','Recebemos o teu contacto'); ?>

<?php $__env->startSection('content'); ?>

    <div class="u-row-container" style="padding: 0px;background-color: transparent">
        <div class="u-row"
             style="Margin: 0 auto;min-width: 320px;max-width: 600px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #ffffff;">
            <div
                style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
                <table>
                    <tr>
                        <td style="padding: 0px;background-color: transparent;" align="center">
                            <table style="width:600px;">
                                <tr style="background-color: #ffffff;">

                                    <td align="center" width="600"
                                        style="width: 600px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;"
                                        valign="top">
                                        <div class="u-col u-col-100"
                                             style="max-width: 320px;min-width: 600px;display: table-cell;vertical-align: top;">
                                            <div style="height: 100%;width: 100% !important;">

                                                <div
                                                    style="height: 100%; padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;">


                                                    <table style="font-family:'Lato',sans-serif;" role="presentation">
                                                        <tbody>
                                                        <tr>
                                                            <td style="overflow-wrap:break-word;word-break:break-word;padding:40px 40px 30px;font-family:'Lato',sans-serif;"
                                                                align="left">

                                                                <div
                                                                    style="line-height: 140%; text-align: left; word-wrap: break-word;">
                                                                    <p style="font-size: 14px; line-height: 140%;"><span
                                                                            style="font-size: 18px; line-height: 25.2px; color: #666666;">Olá, <?php echo e($contact->name); ?></span>
                                                                    </p>
                                                                    <p style="font-size: 14px; line-height: 140%;">
                                                                        &nbsp;</p>
                                                                    <p style="font-size: 14px; line-height: 140%;"><span
                                                                            style="font-size: 18px; line-height: 25.2px; color: #666666;">Foi enviado um novo contacto a partir do website.</span>
                                                                    </p>
                                                                    <p style="font-size: 14px; line-height: 140%;">
                                                                        &nbsp;</p>
                                                                    <p style="font-size: 14px; line-height: 140%;"><span
                                                                            style="font-size: 18px; line-height: 25.2px; color: #666666;">Podes verificar na administração: </span>
                                                                    </p>
                                                                    <p>
                                                                        Nome: <?php echo e($contact->name); ?></p>
                                                                    <p>
                                                                        Email: <?php echo e($contact->email); ?></p>
                                                                    <p>
                                                                        Telefone: <?php echo e($contact->phone); ?></p>
                                                                    <p>
                                                                        Assunto: <?php echo e($contact->subject); ?></p>
                                                                    <p>
                                                                        Mensagem: <?php echo e($contact->message); ?></p>

                                                                    <br>
                                                                    ás: <?php echo e($contact->created_at); ?>

                                                                    </p>
                                                                </div>

                                                            </td>
                                                        </tr>
                                                        </tbody>
                                                    </table>


                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/email/contacts/user.blade.php ENDPATH**/ ?>