<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Nova equipa</h1>

    <form action="<?php echo e(route('admin.teams.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="name">Nome</label>
                    <input type="text" class="form-control" name="nome" id="name" placeholder="Nome" required  value="<?php echo e(old('nome')); ?>" >
                </div>

                <div class="form-group">
                    <label for="name">Imagem</label>
                    <input type="file" class="form-control" name="imagem" id="name" placeholder="Imagem" required  accept="image/*"  value="<?php echo e(old('imagem')); ?>" >
                </div>
                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/teams/create.blade.php ENDPATH**/ ?>