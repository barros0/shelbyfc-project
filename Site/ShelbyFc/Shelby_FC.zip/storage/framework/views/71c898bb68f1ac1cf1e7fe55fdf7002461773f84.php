<?php $__env->startSection('title', 'Forúm - Shelby FC'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content_post">
        <div>
            <p class="post_date"><?php echo e($post->user->name); ?>,
                <span style="color: rgb(0 0 0 / 60%);"><?php echo e($post->created_at); ?></span>
            </p>
            <div class="user_info_forum">
                <img class="post_user_img" src="<?php echo e(asset('images/users/' . $post->user->image)); ?>" alt="user">
                <div class="content">
                    <p style="font-size: 20px; font-weight:bolder;"><?php echo e($post->title); ?></p>
                    <p class="post_body"><?php echo e($post->body); ?></p>
                    <?php $__currentLoopData = $posts_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($image->post_id === $post->id): ?>
                            <img class="post_img" src="<?php echo e(asset('images/forum_posts_images/' . $image->image)); ?>"
                                alt="user">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
        <div class="d-flex justify-content-end">
            <?php echo e($post->comments->count()); ?>

            Comentarios
        </div>
        <div class="create_comment">
            <div class="d-flex flex-column align-items-center">
                <form action="<?php echo e(route('forum.do.comment', $post)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input placeholder="Comentar" type="text" name="comment" id="comment" required>
                    <button type="submit" id="submit">Comentar</button>
                </form>
            </div>
        </div>
        <div class="forum_comments">
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex wrap_post_info">
                    <img src="<?php echo e(asset('images/users/' . $comment->user->image)); ?>" alt="img_user">
                    <div class="container_post_info d-flex flex-column">
                        <p style="font-weight: 800;"><?php echo e($comment->user->name); ?></p>
                        <div class="post_comment">
                            <?php echo e($comment->comment); ?>

                            <p class="comment_reply"><?php echo e($comment->replies->count()); ?> Respostas</p>
                            <form style="display: none;" action="<?php echo e(route('forum.reply', $post->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                                <input type="text" name="reply" id="reply" placeholder="Responder">
                                <button type="submit">Responder</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="container_replies" style="display: none;">
                    <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex wrap_post_info ml-5">
                            <img src="<?php echo e(asset('images/users/' . $reply->user->image)); ?>" alt="img_user">
                            <div class="container_post_info d-flex flex-column">
                                <p style="font-weight: 800;"><?php echo e($reply->user->name); ?></p>
                                <div class="post_comment">
                                    <?php echo e($reply->comment); ?>

                                </div>
                            </div>

                            <form style="display: none;" action="<?php echo e(route('forum.reply', $reply->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                <input type="hidden" name="comment_id" value="<?php echo e($reply->id); ?>">
                                <input type="text" name="reply" id="reply" placeholder="Responder">
                                <button type="submit">Responder</button>
                            </form>
                        </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('js/forum.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/forum/post.blade.php ENDPATH**/ ?>