<?php $__env->startSection('title', 'Inscrever | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

<a style="font-size:25px;" href="<?php echo e(route('admin.inscrever.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>

    <h1>Inscrever para Sócio</h1>
    <div class="form-menu d-flex justify-content-between">

        <a href="<?php echo e(route('admin.inscrever.create')); ?>" class="btn">Adicionar</a>
    </div>

    <div class="table-responsive">
        <table class="datatable">
            <thead>
            <tr class="header">
                <th>ID</th>
                <th>Nome</th>
                <th>Idade Min</th>
                <th>Idade Max</th>
                <th>Preço</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $inscrever; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($preco->id); ?></td>
                    <td><?php echo e($preco->name); ?></td>
                    <td><?php echo e($preco->min_age); ?></td>
                    <td><?php echo e($preco->max_age); ?></td>
                    <td><?php echo e($preco->preco); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.inscrever.edit', $preco)); ?>" class="btn"><i
                                class='bx bx-edit-alt'></i></a>
                        <form action="<?php echo e(route('admin.inscrever.destroy', $preco)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/inscrever/index.blade.php ENDPATH**/ ?>