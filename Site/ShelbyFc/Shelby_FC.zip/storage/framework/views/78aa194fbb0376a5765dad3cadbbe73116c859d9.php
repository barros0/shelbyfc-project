

<?php $__env->startSection('title','Quem Somos | ShelbyFC'); ?>

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="conteudo-sobre">
    <div class="imagem-inicio">

        <div class="parte-baixo-banner">
            <div class="texto-banner">ACERCA DO SHELBY FC</div>
            <p>Encontre aqui mais informações sobre o nosso clube</p>
        </div>
    </div>

    <div class="about-section">
    <div class="texto-banner"><span>|</span> MAIS ACERCA DO SHELBY FC <span>|</span></div>
        <div class="about-text">
            O Shelby Football Club consiste num clube desportivo amador local que visa promover o desporto rei tendo
                um maior foco em jovens desfavorecidos cuja vida é praticamente passada em instituições (7-18 anos).

        </div>

    </div>

    <div class="what-section">

        <div class="texto-banner"><span>|</span> DESCOBRE MAIS DO QUE FAZEMOS <span>|</span></div>

        <div class="ret-section">

        <div class="row-what">
                <div class="ret-what">
                    <i class='bx bx-football'></i>
                    <span class="texto-caixa-sobre">2x Taça de Portugal <br> 7x Campeão Nacional</span>
                </div>
                <div class="ret-what">
                <i class='bx bxs-building' ></i>
                    <span class="texto-caixa-sobre">3 Centro de Treinos<br> 2 567 321€ angariados</span>
                </div>
                <div class="ret-what">
                <i class='bx bxs-user'></i>
                    <span class="texto-caixa-sobre">2340 Sócios <br>3230 Adeptos Habituais</span>
                </div>
                <div class="ret-what">
                <i class='bx bxs-help-circle' ></i>
                <span class="texto-caixa-sobre"> 4.500 Alunos <br> 10 300 Criancas Ajudadas</span>
                </div>
            </div>

        </div>
    </div>


    <div class="team-section">
        <div class="texto-banner"><span>|</span> A NOSSA EQUIPA <span>|</span></div>

        <div class="ret-section">

            <div class="ret">
                <div id="ret1"></div>
                <div id="ret-info">
                    <div class="up-side">
                        <p>João Duarte</p>
                    </div>
                    <div class="down-side"><a href="https://bartz89.github.io/CurriculumVittae/"><i
                                class='bx bx-link'></i></a><a href="https://github.com/bartz89?tab=repositories"><i
                                class='bx bxl-github'></i></a><a
                            href="https://www.linkedin.com/in/jo%C3%A3o-duarte-9289811ab/"><i
                                class='bx bxl-linkedin-square'></i></a></div>
                </div>
            </div>
            <div class="ret">
                <div id="ret2"></div>
                <div id="ret-info">
                    <div class="up-side">
                        <p>João Barros</p>
                    </div>
                    <div class="down-side"><a href="https://barros0.github.io/portfolio-site/"><i
                                class='bx bx-link'></i></a><a href="https://github.com/barros0"><i
                                class='bx bxl-github'></i></a><a
                            href="https://www.linkedin.com/in/jo%C3%A3o-barros-655721162/"><i
                                class='bx bxl-linkedin-square'></i></a></div>
                </div>
            </div>
            <div class="ret">
                <div id="ret3"></div>
                <div id="ret-info">
                    <div class="up-side">
                        <p>André Sousa</p>
                    </div>
                    <div class="down-side"><a href="https://www.andresousadev.com/"><i class='bx bx-link'></i></a><a
                            href="https://github.com/Assado3000"><i class='bx bxl-github'></i></a><a
                            href="https://www.linkedin.com/in/andr%C3%A9-sousa-171b201b1/"><i
                                class='bx bxl-linkedin-square'></i></a></div>
                </div>
            </div>
            <div class="ret">
                <div id="ret4"></div>
                <div id="ret-info">
                    <div class="up-side">
                        <p>Micael Pereira</p>
                    </div>
                    <div class="down-side"><a href="https://github.com/bartz89?tab=repositories"><i
                                class='bx bx-link'></i></a><a href="https://github.com/bartz89?tab=repositories"><i
                                class='bx bxl-github'></i></a><a href="https://github.com/bartz89?tab=repositories"><i
                                class='bx bxl-linkedin-square'></i></a></div>
                </div>
            </div>

        </div>

    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/sobre.blade.php ENDPATH**/ ?>