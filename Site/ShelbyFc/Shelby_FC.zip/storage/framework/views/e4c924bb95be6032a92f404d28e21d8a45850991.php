<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 80px; margin-bottom: 80px">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><p class="m-0">
                            <span>
                                <i class="fa fa-envelope"></i>
                            </span>
                             Verifique seu endereço de e-mail</p></div>

                    <div class="card-body">
                        <?php if(session('resent')): ?>
                            <div class="alert alert-success" role="alert">
                                <p>Um novo link de verificação foi enviado para o seu endereço de e-mail.</p>
                            </div>
                        <?php endif; ?>

                        <p class="m-0">Antes de prosseguir, verifique seu e-mail para obter um link de verificação</p>
                            <br>
                            <p>Se você não recebeu o e-mail:</p>
                        <div class="row">
                            <form class="d-inline" method="POST" action="<?php echo e(route('email.verify.resend')); ?> ">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="btn btn-primary">Clique aqui para pedir outro</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/auth/verify.blade.php ENDPATH**/ ?>