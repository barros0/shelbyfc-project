<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.categories.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Nova Categoria</h1>

    <form action="<?php echo e(route('admin.categories.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="name">Nome Da Categoria</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name"
                           value="<?php echo e(old('name')); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>