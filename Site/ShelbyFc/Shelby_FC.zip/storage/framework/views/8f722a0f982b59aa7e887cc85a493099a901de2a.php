<nav id="navbar" class="d-flex">
    <div class="navbar-logo-container d-flex justify-content-center">
        <a class="" href="<?php echo e(route('index')); ?>">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
        </a>
        <i onclick="openNav()" id="menu_hamburguer"class='bx bx-menu'></i>
    </div>
    <div class="navbar-menu-container">
        <div class="navbar-info-container d-flex flex-row justify-content-around">
            <div class="d-flex justify-content-around align-items-center">
                <p class="d-flex align-items-center"><i class='bx bxs-phone'></i> 244 144 102</p>
                <div class="line"></div>
                <p class="d-flex align-items-center"><i class='bx bxs-envelope'></i> shelbyfc@gmail.com</p>
            </div>
            <div class="d-flex justify-content-around align-items-center">
                <?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('withdraw')); ?>"><?php echo e(Auth::user()->balance); ?>€</a>

                    <a href="<?php echo e(route('perfil')); ?>">Minha conta</a>

                    <?php if(Auth::user()->is_admin): ?>
                        <div class="line"></div>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">Administração</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                    <div class="line"></div>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="navbar-navigation-container d-flex">
            <div class="navbar-third-container d-flex align-items-center justify-content-center">
                <ul>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" target="_blank"
                            href="https://teste.social-bubble.pt">
                            Loja Online
                        </a>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('forum.home')); ?>">
                            Forúm
                        </a>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('noticias')); ?>">
                            Notícias
                        </a>
                    </li>
                    <li>
                        Jogos
                        <ul>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('jogos')); ?>">
                                    Calendário
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('resultados')); ?>">
                                    Resultados
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('tickets')); ?>">
                                    Bilheteira
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('tobet')); ?>">
                                    Apostar
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        Suporte
                        <ul>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('sobre')); ?>">
                                    Quem Somos
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('faqs')); ?>">
                                    FAQs
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('terms')); ?>">
                                    Termos e Condições
                                </a>
                            </li>
                            <li>
                                <a class="d-flex align-items-center justify-content-center"
                                    href="<?php echo e(route('contacts')); ?>">
                                    Contactos
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="d-flex align-items-center justify-content-center" href="<?php echo e(route('inscrever')); ?>">
                            Sócio
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div id="myNav" class="overlay">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="overlay-content">
            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('withdraw')); ?>"><?php echo e(Auth::user()->balance); ?>€</a>

                <a href="<?php echo e(route('perfil')); ?>">Minha conta</a>

                <?php if(Auth::user()->is_admin): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Administração</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
                <div class="line"></div>
                <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
            <a href="https://teste.social-bubble.pt">Loja Online</a>
            <a href="<?php echo e(route('forum.home')); ?>">Forum</a>
            <a href="<?php echo e(route('noticias')); ?>">Notícias</a>
            <p id="jogos">Jogos<i class='bx bxs-down-arrow'></i></p>
            <div id="jogos_menu" style="display:none">
                <a class="" href="<?php echo e(route('jogos')); ?>">
                    Calendário
                </a>
                <a class="" href="<?php echo e(route('resultados')); ?>">
                    Resultados
                </a>
                <a class="" href="<?php echo e(route('tickets')); ?>">
                    Bilheteira
                </a>

                <a class="" href="<?php echo e(route('tobet')); ?>">
                    Apostar
                </a>
            </div>
            <p id="suporte">Suporte<i class='bx bxs-down-arrow'></i></p>


            <div id="suporte_menu" style="display:none">
                <a class="" href="<?php echo e(route('sobre')); ?>">
                    Quem Somos
                </a>

                <a class="" href="<?php echo e(route('faqs')); ?>">
                    FAQs
                </a>

                <a class="" href="<?php echo e(route('terms')); ?>">
                    Termos e Condições
                </a>

                <a class="" href="<?php echo e(route('contacts')); ?>">
                    Contactos
                </a>
            </div>
            <a href="<?php echo e(route('inscrever')); ?>">Sócio</a>

        </div>
    </div>
</nav>
<?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/partials/nav.blade.php ENDPATH**/ ?>