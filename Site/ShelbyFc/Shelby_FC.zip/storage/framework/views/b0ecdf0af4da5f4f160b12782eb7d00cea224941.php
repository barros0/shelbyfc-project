<?php $__env->startSection('title', 'Novo jogo | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.games.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Novo jogo</h1>

    <form action="<?php echo e(route('admin.games.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">

            <div class="form-group col-md-6">
                <label for="">Stock bilhetes</label>
                <input class="form-control" name="stock_bilhetes" type="number" required value="<?php echo e(old('stock_bilhetes')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="data_jogo">Data limite de compra de bilhetes</label>
                <input class="form-control" name="data_limite_bilhetes" type="datetime-local" id="data_limite_bilhetes" required value="<?php echo e(old('data_limite_bilhetes')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="image">Preço bilhete</label>
                <input class="form-control" name="preco_bilhete" type="number" step="0.01" required value="<?php echo e(old('preco_bilhete')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="image">Preço bilhete sócio</label>
                <input class="form-control" name="preco_bilhete_socio" type="number" step="0.01" required value="<?php echo e(old('preco_bilhete_socio')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="local">Local</label>
                <input type="text" class="form-control" name="local" id="local" placeholder="Enter Title"
                       required value="<?php echo e(old('local')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="data_jogo">Data do jogo</label>
                <input class="form-control" name="data_jogo" type="datetime-local" id="data_jogo" required value="<?php echo e(old('data_jogo')); ?>">
            </div>

            <div class="form-group col-md-6">
                <label>Equipa adverária</label>
                <div class="form-group">
                    <select required name="equipa" >
                        <option value="">Selecione...</option>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Inserir</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/games/create.blade.php ENDPATH**/ ?>