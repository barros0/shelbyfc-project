

<?php $__env->startSection('title','Contactos | ShelbyFC'); ?>

<?php $__env->startSection('content'); ?>

<div class="conteudo-contactos">
    <div class="imagem-inicio">

      <div class="parte-baixo-banner">
        <div class="texto-banner">CONTACTA-NOS</div>
        <p>Encontre aqui mais informações de como nos pode contactar</p>
      </div>
    </div>

    <div class="contact-section">
            <div class="left-side"></div>
            <div class="right-side"></div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/contactos.blade.php ENDPATH**/ ?>