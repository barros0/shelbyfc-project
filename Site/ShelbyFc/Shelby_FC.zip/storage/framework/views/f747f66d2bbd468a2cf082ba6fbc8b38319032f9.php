


<?php $__env->startSection('title', 'Forum Posts | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Posts</h1>

    <div class="table-responsive">
        <table class="datatable">
            <thead>
                <tr class="header">
                    <th>ID</th>
                    <th>Titulo</th>
                    <th>Corpo</th>
                    <th>Ver</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->body); ?></td>
                        <td><a href="<?php echo e(route('admin.forum_posts.show', $post)); ?>">Ver</a></td>
                        <td>
                            <form action="<?php echo e(route('admin.forum_posts.destroy', $post)); ?>" method="post">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit"><i class='bx bx-trash'></i></button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/forum_posts/index.blade.php ENDPATH**/ ?>