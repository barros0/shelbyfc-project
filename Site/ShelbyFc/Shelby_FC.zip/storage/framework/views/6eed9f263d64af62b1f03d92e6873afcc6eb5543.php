

<?php $__env->startSection('title', 'Notícias | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container_all_news">
        <div class="nav_categories">
            <div class="news_from_category">
                <a id="filtros_news" class="<?php echo e(Route::is(route('noticias')) ? 'selected_category' : ''); ?>">Categorias<i
                        class='bx bx-filter'></i></a>
                <a href="<?php echo e(route('noticias')); ?>"
                    class="<?php echo e(Route::currentRouteName() == 'noticias' ? 'selected_category' : ''); ?>">Geral</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('news.categorie', [$category->id])); ?>"
                        class="<?php echo e(url()->current() == route('news.categorie', $category->id) ? 'selected_category' : ''); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="news_category">
            <?php if($noticias->count() < 1): ?>
                <h2 class="no_news">Não existe nenhuma notícia com esta categoria</h2>
            <?php else: ?>
                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="news_body" href="<?php echo e(route('NoticiaModal', $noticia->id)); ?>">
                        <img src="<?php echo e(asset('images/noticias/' . $noticia->image)); ?>" alt="noticia">
                        <div class="date_category">
                            <p class="news_date"><?php echo e($noticia->created_at->format('Y-m-d')); ?></p>
                            <p class="newsbody_category"><?php echo e($noticia->categorie->name); ?></p>
                        </div>
                        <h2><?php echo e($noticia->title); ?></h2>
                        <p class="new_small_description"><?php echo $noticia->small_description; ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="container_news_pages">
            <?php if($noticias->hasPages()): ?>
                <div class="pagination-wrapper">
                    <?php echo e($noticias->links('pagination::bootstrap-4')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="<?php echo e(asset('js/news.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/noticias.blade.php ENDPATH**/ ?>