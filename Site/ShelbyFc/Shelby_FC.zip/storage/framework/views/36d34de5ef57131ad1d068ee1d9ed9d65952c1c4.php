

<?php $__env->startSection('content-perfil'); ?>
<form action="<?php echo e(route('user.update.password')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-6 form-group">
            <label class="form-label" for="atual_password">Password atual</label>
            <input class="" type="password" name="atual_password" id="atual_password">
        </div>

        <div class="col-lg-6 form-group">
            <label class="form-label" for="nova_password">Nova password</label>
            <input class="" type="password" name="nova_password" id="nova_password">
        </div>
        <div class="col-lg-6 form-group">
            <label class="form-label" for="nova_password_confirmation">Confirmação da nova password</label>
            <input class="" type="password" name="nova_password_confirmation" id="nova_password_confirmation">
        </div>
    </div>

    <div class="col-12 text-center">
        <button type="submit" class="btn">
            <i class="fa-solid fa-floppy-disk"></i>
            Alterar
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/perfil/seguranca.blade.php ENDPATH**/ ?>