<?php $__env->startSection('title', 'Categories | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Editar Categoria</h1>

    <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-9">
                <div class="form-group">
                    <label for="name">Title</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e($category->name); ?>"
                        required>
                </div>
                <button type="submit" class="btn btn-primary">Inserir</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>