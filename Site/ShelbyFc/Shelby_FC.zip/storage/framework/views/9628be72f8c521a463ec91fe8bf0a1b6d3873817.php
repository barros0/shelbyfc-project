<footer class="ct-footer">
    <div class="container">
        <ul class="ct-footer-list text-center-sm">
            <li>
                <a href="https://teste.social-bubble.pt" id="loja_online_footer" class="ct-footer-list-header">Loja
                    Online</a>
            </li>
            <li>
                <h2 class="ct-footer-list-header">Geral</h2>
                <ul>
                    <li>
                        <a href="<?php echo e(route('forum.home')); ?>">Forúm</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('noticias')); ?>">Notícias</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('inscrever')); ?>">Sócio</a>
                    </li>
                </ul>
            </li>
            <li>
                <h2 class="ct-footer-list-header">Jogos</h2>
                <ul>
                    <li>
                        <a href="<?php echo e(route('jogos')); ?>">Calendário</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('resultados')); ?>">Resultados</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('forum.home')); ?>">Bilheteira</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('tobet')); ?>">Apostar</a>
                    </li>
                </ul>
            </li>
            <li>
                <h2 class="ct-footer-list-header">Suporte</h2>
                <ul>
                    <li>
                        <a href="<?php echo e(route('sobre')); ?>">Quem Somos</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('faqs')); ?>">FAQS</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('forum.home')); ?>">Termos e Condições</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contacts')); ?>">Contactos</a>
                    </li>
                </ul>
            </li>
        </ul>
        <div class="ct-footer-meta text-center-sm">
            <div class="row">
                <div class="col-sm-6 col-md-2">

                </div>
                <div class="col-sm-6 col-md-3">
                    <img alt="logo" src="<?php echo e(asset('images/logo.svg')); ?>">
                </div>
                <div class="col-sm-6 col-md-2 ct-u-paddingTop10">

                </div>
                <div class="col-sm-6 col-md-2 ct-u-paddingTop10">
                    <address>
                        <span>SHELBY FC<br></span><span>Morada:</span> R. Gen. Norton de Matos Apartado 4133<br>
                        <span>Phone: <a href="tel:244144102">244 144 102</a></span>
                    </address>
                </div>
                <div class="col-sm-6 col-md-3">

                </div>
            </div>
        </div>
    </div>
</footer>
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/partials/footer.blade.php ENDPATH**/ ?>