<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<header>
    <div class="navbar-esq">
        <div class="logo">
            <a class="link-logo" href="<?php echo e(route('index')); ?>">
                <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo">
            </a>
        </div>
    </div>

    <div class="navbar-dir">

        <a href="<?php echo e(route('register')); ?>" id="conta">CRIAR CONTA</a>

    </div>
</header>

<div id="seccao-login" class="d-flex justify-content-center align-items-center fullvh">
    <section id="login" class="col-12">
        <div class="row text-center col-12 title-login">
            <h3 class="tit">Recuperar password!</h3>
        </div>
        <div class="login-wrapper">
            <div class="login-regular">
                <form class="form-login" method="post" action="<?php echo e(route('forget.password.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="email">EMAIL</label>
                    <input value="<?php echo e(old('email')); ?>" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" id="email" name="email" placeholder="nome@exemplo.com" required autocomplete="email" autofocus onkeyup="enableSubmit()">


                    <?php if($errors->all()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($error); ?></strong>
                    </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>




                    <input type="submit" id="login-btn" class="btn-login" value="INICIAR SESSÃO" disabled="disabled">
                </form>
            </div>


        </div>
        <div class="row text-center col-12 title-login">
            <a href="<?php echo e(route('forget.password.get')); ?>" class="trouble">NÃO CONSEGUE INICIAR SESSÃO?</a>
            <div class="linha-ajuda"></div>
        </div>
        <div class="row footer-bg col-12 title-login"></div>

    </section>
</div>

<div class="background">
    <div class="dir"></div>
    <div class="left"></div>
</div>


<script src="<?php echo e(asset('js/login.js')); ?>"></script>


<?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/auth/forgetPassword.blade.php ENDPATH**/ ?>