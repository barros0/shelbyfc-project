


<?php $__env->startSection('title', 'Contactos | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <a style="font-size:25px;" href="<?php echo e(route('admin.contacts.index')); ?>"><i class='bx bx-left-arrow-alt'></i></a>
    <h1>Contacto de <?php echo e($contact->name); ?> </h1>
    <p>ás <?php echo e($contact->created_at); ?></p>

    <div class="row">
        <div class="form-group col-md-6">
            <label for="email">Email</label>
            <input disabled type="text" class="form-control" value="<?php echo e($contact->email); ?>">
        </div>

        <div class="form-group col-md-6">
            <label for="email">Telefone</label>
            <input disabled type="text" class="form-control" value="<?php echo e($contact->phone); ?>">
        </div>


        <div class="form-group col-12">
            <label for="email">Assunto</label>
            <input disabled type="text" class="form-control" value="<?php echo e($contact->subject); ?>">
        </div>

        <div class="form-group col-12">
            <label for="email">Mensagem</label>
            <textarea disabled type="text" class="form-control"><?php echo e($contact->message); ?></textarea>
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/contacts/show.blade.php ENDPATH**/ ?>