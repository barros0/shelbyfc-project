<?php $__env->startSection('title', 'Jogos | Shelby FC'); ?>

<?php $__env->startSection('content'); ?>


    <h1>Jogos</h1>

    <div class="form-menu d-flex justify-content-between">
        <a href="<?php echo e(route('admin.games.create')); ?>" class="btn">Adicionar</a>
    </div>

    <div class="table-responsive">

        <table  class="datatable">
          <thead>
            <tr class="header">
                <th>ID</th>
                <th>Adversário</th>
                <th>Preço</th>
                <th>Preço sócio</th>
                <th>Local</th>
                <th>Bilhetes disponiveis</th>
                <th>Nº apostas</th>
                <th>Data</th>
                <th>Actions</th>
                <th>Resultados</th>
            </tr> </thead> <tbody>
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($game->id); ?></td>
                    <td><?php echo e($game->opponent->name); ?></td>
                    <td><?php echo e($game->ticket_price); ?>€</td>
                    <td><?php echo e($game->ticket_price_partner); ?>€</td>
                    <td><?php echo e($game->location); ?></td>
                    <td><?php echo e($game->stock_tickets); ?></td>
                    <td><?php echo e($game->bets->count()); ?></td>
                    <td><?php echo e($game->datetime_game); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.games.edit', $game)); ?>" class="btn"><i class='bx bx-edit-alt'></i></a>
                        <form action="<?php echo e(route('admin.games.destroy', $game)); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"><i class='bx bx-trash'></i></button>
                        </form>
                    </td>
                    <td>
                        <?php if($game->result_home === null || $game->result_opponent === null): ?>
                            <a href="<?php echo e(route('admin.games.show', $game)); ?>" class="btn">Publicar Resultado</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.games.show', $game)); ?>" class="btn">Ver Resultado</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/admin/games/index.blade.php ENDPATH**/ ?>