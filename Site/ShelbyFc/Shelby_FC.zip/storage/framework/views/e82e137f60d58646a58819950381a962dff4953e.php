<?php $__env->startSection('title', 'Notícias - Shelby FC'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content_noticia container">
        <img class="img_thumb" src="<?php echo e(asset('images/noticias/' . $noticia->image)); ?>" alt="">
        <p class="single_noticia"><?php echo e($noticia->categorie->name); ?></p>
        <h1><?php echo e($noticia->title); ?></h1>
        <h3><?php echo e($noticia->small_description); ?></h3>
        <p><?php echo $noticia->body; ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/NoticiaModal.blade.php ENDPATH**/ ?>