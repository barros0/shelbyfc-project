

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Calendário de Jogos  - Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <div class="background-foto-calendario">
        <h1 class="tit-principal">Calendário de Jogos</h1>
    </div>

    <div class="container my-4">

        <div class="row">

            <div class="calendar">

                <?php $__currentLoopData = $proximos_jogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($game->NextGames()): ?>

                    <div class="match-day">
                        <div class="match-details">
                            <span class="match-date"><?php echo e($data = date('d M y',strtotime($game->datetime_game))); ?></span>
                            <span class="match-hours"><?php echo e($hora = date('H:i',strtotime($game->datetime_game))); ?></span>
                            <span class="match-location"><?php echo e($game->location); ?></span>
                            <?php if($game->stock_tickets > 0): ?>
                            <div class="mt-2 d-flex text-center">
                                <a href="/comprar-bilhete" class="btn btn-registo" style="color:white; font-size:15px">Bilhetes</a>
                            </div>
            
                        <?php endif; ?>
                        </div>
                        <div class="teams">
                            <div class="match-home-team">
                                <img src="<?php echo e(asset('images/liga/shelby_fc.png')); ?>" alt="Shelby FC" class="match-team">
                                <span class="match-type">Shelby F.C</span>
                            </div>
                            <div class="match-vs-half"><span class="match-type">Amigável</span>
                                <h3 class="match-day-vs">VS</h3></div>
                            <div class="match-away-team">
                                <img src="<?php echo e(asset('images/liga/'.$game->opponent->image)); ?>"
                                     alt="<?php echo e($game->opponent->name); ?>" class="match-team">
                                <span class="match-type"><?php echo e($game->opponent->name); ?></span>
                            </div>
                        </div>

                


                    </div>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/jogos.blade.php ENDPATH**/ ?>