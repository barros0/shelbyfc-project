<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Inscrever - Shelby FC'); ?>

<?php $__env->startSection('content'); ?>

    <div class="background-foto">
        <h1 class="tit-principal">NÃO FIQUES NO ESCURO.<br>ACENDE A TUA CHAMA.</h1>
        <img src="<?php echo e(asset('images/inscrever/credit-card.png')); ?>" alt="Cartão Sócio" class="cartao-socio">
    </div>
    <div class="vantagens">
        <h1 class="tit-vant">UM CARTÃO...</h1>
        <div class="row-vant">
            <div class="vantagem">
                <i class='bx bxs-discount icon-vant'></i>
                <span class="texto-vant">DESCONTOS NA LOJA</span>
            </div>
            <div class="vantagem">
                <i class='bx bxs-trophy icon-vant'></i>
                <span class="texto-vant">PRÉMIOS E PASSATEMPOS</span>
            </div>
            <div class="vantagem">
                <i class='bx bx-dumbbell icon-vant'></i>
                <span class="texto-vant">UTILIZAÇÃO DAS INSTALAÇÕES</span>
            </div>
        </div>
        <h1 class="tit-vant">...CENTENAS DE VANTAGENS</h1>
    </div>
    <div id="inscrever" class="fullpage-row">
        <div class="metade">

            <h1 class="titulo-sec-3">INSCRIÇÃO PARA SÓCIO</h1>

            <div class="login-regular">
                <form class="form-login" id="inscrever-socio" method="post" enctype="multipart/form-data"
                    action="<?php echo e(route('inscrever.post')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="tab">
                        <label for="nif">NIF</label>
                        <input type="number" name="nif" placeholder="NIF" required value="<?php echo e(Auth::user()->nif); ?>">
                        <label for="birthdate">Data de Nascimento</label>
                        <input type="date" name="birthdate" placeholder="Data de Nascimento" required
                            value="<?php echo e(Auth::user()->birthdate); ?>">
                    </div>

                    <div class="tab">
                        <label for="cc">Cartão de Cidadão (Ou outro documento de identificação)</label>
                        <input type="file" name="cc" placeholder="cc" required>

                    </div>

                    <div class="tab">
                        <label for="morada">Morada</label>
                        <input type="text" name="morada" placeholder="Morada" required
                            value="<?php echo e(Auth::user()->address); ?>">
                        <label for="cidade">Cidade</label>
                        <input type="text" name="cidade" placeholder="Cidade" required value="<?php echo e(Auth::user()->city); ?>">
                        <label for="zipcode">Código Postal</label>
                        <input type="text" name="zipcode" placeholder="Código Postal" required
                            value="<?php echo e(Auth::user()->postal_code); ?>">
                        <label for="pais">País</label>
                        <select class="" name="pais" id="pais">
                            <option value="">Selecione o seu país</option>
                            <?php $__currentLoopData = $nacionalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($country->id == Auth::user()->country_id): ?> selected <?php endif; ?> value="<?php echo e($country->id); ?>">
                                    <?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="botoes">
                        <button type="button" id="prevBtn" class="btn-registo" onclick="nextPrev(-1)">VOLTAR</button>
                        <button type="button" id="nextBtn" class="btn-registo" onclick="nextPrev(1)">SEGUINTE</button>

                    </div>
                    <div style="text-align:center;margin-top:40px;">
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                    </div>
                </form>
            </div>

        </div>

        <div class="metade">

            <h1 class="titulo-sec-3">TABELA DE PREÇOS</h1>

            <div class="tabela-preco">
                <table>
                    <tbody>
                        <tr class="header">
                            <th>Pacote</th>
                            <th>Idade</th>
                            <th>Mensalidade</th>
                        </tr>
                        <?php $__currentLoopData = $socio_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sociopacote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--para cada registo de pacote-->
                            <tr>
                                <td><?php echo e($sociopacote->name); ?></td>
                                <td><?php echo e($sociopacote->min_age); ?> - <?php echo e($sociopacote->max_age); ?></td>
                                <td><?php echo e($sociopacote->preco); ?> €/Mês</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

    <div class="inscricao"></div>
    <script src="<?php echo e(asset('js/functions.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\submi\OneDrive\Ambiente de Trabalho\shelbyfc-project\Site\ShelbyFc\resources\views/inscrever.blade.php ENDPATH**/ ?>