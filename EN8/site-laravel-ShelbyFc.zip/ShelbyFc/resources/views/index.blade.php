@extends('layouts.master')

@section('title','ShelbyFC')


@section('content')

  <h1>  <a href="{{route('login')}}">Login</a></h1>
@endsection
