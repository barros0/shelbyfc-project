@include('partials.head')

@include('partials.nav')


@yield('content')


@include('partials.footer')

